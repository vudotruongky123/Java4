package poly.com.controller;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet({ "/bai2", "/bai2/tinhchuvi", "/bai2/tinhdientich", "/bai2/signup" })
public class Bai2controller extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("/bai2.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uri = req.getRequestURI();
		if (uri.contains("/bai2/tinhchuvi")) {
			req.setAttribute("result", tinhChuViTamGiac(req, resp));
			req.getRequestDispatcher("/bai2.jsp").forward(req, resp);
		} else if (uri.contains("/bai2/tinhdientich")) {
			req.setAttribute("result", tinhDienTichTamGiac(req, resp));
			req.getRequestDispatcher("/bai2.jsp").forward(req, resp);
		} else if (uri.contains("/bai2/signup")) {
			dangKy(req, resp);
			req.getRequestDispatcher("/infor.jsp").forward(req, resp);
		}
	}

	protected double tinhChuViTamGiac(HttpServletRequest req, HttpServletResponse resp) {
		double a, b, c;
		a = Double.parseDouble(req.getParameter("a"));
		b = Double.parseDouble(req.getParameter("b"));
		c = Double.parseDouble(req.getParameter("c"));
		double chuViTamGiac = a + b + c;
		return chuViTamGiac;
	}

	protected double tinhDienTichTamGiac(HttpServletRequest req, HttpServletResponse resp) {
		double a, b, c;
		a = Double.parseDouble(req.getParameter("a"));
		b = Double.parseDouble(req.getParameter("b"));
		c = Double.parseDouble(req.getParameter("c"));
		double p = (a + b + c) / 2;
		double dienTichTamGiac = Math.sqrt(p * (p - a) * (p - b) * (p - c));
		return dienTichTamGiac;
	}

	protected void dangKy(HttpServletRequest req, HttpServletResponse resp) {
		String username, password, gender, maried, country, note;
		username = req.getParameter("username");
		password = req.getParameter("password");
		gender = "0".equalsIgnoreCase(req.getParameter("gender")) ? "Nam" : "Nữ";
		maried = "1".equalsIgnoreCase(req.getParameter("maried")) ? "Đã có gia đình" : "Chưa có gia đình";
		country = req.getParameter("country");
		String hobbies[] = req.getParameterValues("hobbies"); // Lấy nhiều checkbox
		note = req.getParameter("note");

		req.setAttribute("username", username);
		req.setAttribute("password", password);
		req.setAttribute("gender", gender);
		req.setAttribute("maried", maried);

		if ("VN".equalsIgnoreCase(country)) {
			req.setAttribute("country", "Việt Nam");
		} else if ("RS".equalsIgnoreCase(country)) {
			req.setAttribute("country", "Nga");
		} else {
			req.setAttribute("country", "Mỹ");
		}

		// Xử lý hobbies
		String hobbiesText = "";
		if (hobbies != null) {
			StringBuilder sb = new StringBuilder();
			for (String h : hobbies) {
				switch (h) {
				case "R":
					sb.append("Đọc sách, ");
					break;
				case "T":
					sb.append("Du lịch, ");
					break;
				case "M":
					sb.append("Âm nhạc, ");
					break;
				case "O":
					sb.append("Khác, ");
					break;
				}
			}
			// Xóa dấu phẩy cuối cùng
			hobbiesText = sb.substring(0, sb.length() - 2);
		} else {
			hobbiesText = "Không có";
		}
		req.setAttribute("hobbies", hobbiesText);
		req.setAttribute("note", note);
		
		System.out.println(">> " + username);
		System.out.println(">> " + gender);
		System.out.println(">> " + maried);
		System.out.println(">> " + country);
		System.out.println(">> " + hobbiesText);
	}
}
