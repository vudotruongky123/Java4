package poly.com.servlet;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class TestConnect {
	public static void main(String[] args) {
//		create();
//		delete();
//		update();
		findAll();
		findByRole(true);
		findByKeyword("duc.hoang@example.com", "KHÔNG YÊU EM THÌ YÊU AI?");
		findPage(0, 3);
	}

	private static void findAll() {
		// Nạp Persistence
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		// Lớp này để thao tác với DB
		EntityManager em = emf.createEntityManager();

		try {
			String sql = "SELECT o1 FROM User o1";
			// Truy vấn
			TypedQuery<User> query = em.createQuery(sql, User.class);
			List<User> list = query.getResultList();

			for (User user : list) {
				System.out.println(">>Email: " + user.getEmail());
				System.out.println(">>Role: " + user.getAdmin());
				System.out.println(">>Id: " + user.getId());
				System.out.println(">>Password: " + user.getPassword());
				System.out.println(">>Fullname: " + user.getFullname());
			}
			System.out.println("Truy vấn thành công!");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Sai");
		}
		em.close();
		emf.close();
	}

	private static void create() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {

			em.getTransaction().begin();
			User entity = new User();

			entity.setId("TEST006");
			entity.setPassword("test123");
			entity.setFullname("Nguyễn Test");
			entity.setEmail("nguyentest@example.com");
			entity.setAdmin(true);

			em.persist(entity); // Lưu vào DB

			em.getTransaction().commit(); // Xác nhận thay đổi
			System.out.println("Thêm user thành công!");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Thêm thất bại");
		}

	}

	private static void delete() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin();
			User entity = em.find(User.class, "TEST006");
			em.remove(entity); // Xóa

			em.getTransaction().commit(); // Chấp nhận kết quả thao tác
			System.out.println("Xóa thành công");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Xóa thất bại!");
		}
		em.close();
		emf.close();
	}

	private static void update() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin();
			User entity = em.find(User.class, "DUC005");
			entity.setPassword("ILOVEYOUSO");
			entity.setAdmin(true);
			entity.setFullname("KHÔNG YÊU EM THÌ YÊU AI?");
			em.merge(entity); // Cập nhật

			em.getTransaction().commit(); // Chấp nhận kết quả thao tác
			System.out.println("Cập nhật thành công!");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Cập nhật thất bại!");
		}
		em.close();
		emf.close();
	}

	public static void findByRole(boolean role) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			String sql = "SELECT o FROM User o WHERE o.admin=:role";
			TypedQuery<User> query = em.createQuery(sql, User.class);
			query.setParameter("role", role);

			// Truy
			List<User> list = query.getResultList();

			for (User user : list) {
				System.out.println(">>Email: " + user.getEmail());
				System.out.println(">>Is Admin: " + user.getAdmin());
			}
			System.out.println("Truy vấn thành công");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Truy vấn thất bại!");
		}
		em.close();
		emf.close();
	}

	public static void findByKeyword(String email, String fullname) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			String sql = "SELECT o FROM User o WHERE o.fullname LIKE :email OR o.fullname LIKE :fullname";
			TypedQuery<User> query = em.createQuery(sql, User.class);
			query.setParameter("email", email);
			query.setParameter("fullname", fullname);

			// Truy 
			List<User> list = query.getResultList();

			for (User user : list) {
				System.out.println(">>Email: " + user.getEmail());
				System.out.println(">>Is Admin: " + user.getAdmin());
			}
			System.out.println("Truy vấn thành công");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Truy vấn thất bại!");
		}
		em.close();
		emf.close();
	}

	public static void findPage(int page, int size) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("PolyOE");
		EntityManager em = emf.createEntityManager();
		try {
			String sql = "SELECT o FROM User o";
			
			// Ví dụ có 100 phần tử
			// Truyền page = 3, size = 15 >> có nghĩa là muốn lấy 15 phần tử bắt đầu từ phần tử thứ 3
			TypedQuery<User> query = em.createQuery(sql, User.class);
			query.setFirstResult(page * size);
			query.setMaxResults(size);

			// Truy
			List<User> list = query.getResultList();

			for (User user : list) {
				System.out.println(">>Email: " + user.getEmail());
				System.out.println(">>Is Admin: " + user.getAdmin());
			}
			System.out.println("Truy vấn thành công");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Truy vấn thất bại!");
		}
		em.close();
		emf.close();
	}
}
