package poly.com.servlet;

import java.io.IOException;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.dao.UserDAO;
import poly.com.entity.User;

@WebServlet({ "/user/index", "/user/create", "/user/update", "/user/delete", "/user/reset", "/user/edit/*",
		"/user/delete/*" })
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UserServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	UserDAO dao = new UserDAO();
	User user = null;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uri = req.getRequestURI().toString();
		resp.setCharacterEncoding("utf-8");

		if (uri.contains("delete")) {
			if (req.getParameter("id") != null) {
				dao.remove(req.getParameter("id"));
				req.setAttribute("message", "Delete success");
			} else {
				user = new User();	// Create an user null
				req.setAttribute("user", user);
			}
		} else if (uri.contains("edit")) {
			if (req.getParameter("id") != null) {
				user = dao.findById(req.getParameter("id"));
				req.setAttribute("user", user);
			}
		}
		findAll(req, resp);
		req.getRequestDispatcher("/views/user.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uri = req.getRequestURI().toString();
		resp.setCharacterEncoding("utf-8");
		if (uri.contains("create")) {
			create(req, resp);
		} else if (uri.contains("update")) {
			update(req, resp);
		} else if (uri.contains("delete")) {
			delete(req, resp);
		} else if (uri.contains("reset")) {
			req.setAttribute("user", new User());
		}
		findAll(req, resp);
		req.getRequestDispatcher("/views/user.jsp").forward(req, resp);
	}

	// Create
	protected void create(HttpServletRequest req, HttpServletResponse resp) {
		try {
			user = new User();
			BeanUtils.populate(user, req.getParameterMap());
			dao.create(user);
			req.setAttribute("message", "Create success!");
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("error", "Error: " + e.getMessage());
		}
	}

	// Update
	protected void update(HttpServletRequest req, HttpServletResponse resp) {
		try {
			user = new User();
			BeanUtils.populate(user, req.getParameterMap());
			if (user.getId() != null) {
				dao.update(user);
				req.setAttribute("message", "Update success!");
			}
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("error", "Error: " + e.getMessage());
		}
	}

	// Delete
	protected void delete(HttpServletRequest req, HttpServletResponse resp) {
		try {
			user = new User();
			BeanUtils.populate(user, req.getParameterMap());
			if (user.getId() != null) {
				dao.remove(user.getId());
				req.setAttribute("message", "Delete success!");
			}
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("error", "Error: " + e.getMessage());
		}
	}

	// Find All
	protected void findAll(HttpServletRequest req, HttpServletResponse resp) {
		try {
			List<User> list = dao.findAll();
			req.setAttribute("users", list);
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("error", "Error: " + e.getMessage());
		}
	}
}
