package poly.com.dao;

import java.util.List;

import poly.com.entity.User;

public interface UserImpl<E, K> {
	List<E> findAll();
	User findById(K k);
	void create(E e);
	void update(E e);
	void deleteById(K k);
}
