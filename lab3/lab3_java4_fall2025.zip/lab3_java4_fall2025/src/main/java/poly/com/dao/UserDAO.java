package poly.com.dao;

import java.util.List;

import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import poly.com.entity.User;
import poly.com.utils.JpaUtils;

public class UserDAO {
	private EntityManager em = JpaUtils.getEntityManager();

	// Thêm
	public User create(User user) {
		try {
			em.getTransaction().begin();
			em.persist(user); // Hành động thêm
			em.getTransaction().commit(); // Đồng ý thao tác
			return user;
		} catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}

	// Cập nhật
	public User update(User user) {
		try {
			em.getTransaction().begin();
			em.merge(user); // Hành động cập nhật
			em.getTransaction().commit(); // Đồng ý thao tác
			return user;
		} catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}

	// Xóa
	public User remove(String id) {
		try {
			em.getTransaction().begin();
			User user = this.findById(id); // Tìm User theo id được truyền vào
			if (user != null) {
				em.remove(user); // Hành động xóa
			} else {
				throw new RuntimeException("User not found with id: " + id);
			}
			em.getTransaction().commit(); // Đồng ý thao tác
			return user;
		} catch (Exception e) {
			em.getTransaction().rollback();
			throw new RuntimeException(e);
		}
	}

	// Tìm theo Id
	public User findById(String id) {
		return em.find(User.class, id);
	}

	// Tim theo Role
	public List<User> findByRole(boolean role) {
		String jpql = "SELECT o FROM User o WHERE o.admin=:role1";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		query.setParameter("role1", role);
		return query.getResultList();
	}

	// Tim theo tu khoa
	public List<User> findByKeyWord(String keyword) {
		String jpql = "SELECT o FROM User o WHERE o.fullname like :fullname";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		query.setParameter("fullname", "%" + keyword + "%");
		return query.getResultList();
	}

	// Tim theo tu khoa
	public List<User> findOne(String username, String password) {
		try {
			String jpql = "SELECT o FROM User o WHERE o.id = :id AND o.password = :password";
			TypedQuery<User> query = em.createQuery(jpql, User.class);
			query.setParameter("id", username);
			query.setParameter("password", password);
			return query.getResultList();
		} catch (Exception e) {
			return null; // Not found user
		}
	}

	// Tìm theo Email
	public List<User> findByEmail(String email) {
		String jpql = "SELECT o FROM User o WHERE o.email = :email";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		query.setParameter("email", email);
		return query.getResultList();
	}

	// Tìm theo trang
	public List<User> findPage(int page, int size) {
		String jpql = "SELECT o FROM User o";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		query.setFirstResult(page * size);
		query.setMaxResults(size);
		return query.getResultList();
	}

	// Lấy hết
	public List<User> findAll() {
		String jpql = "SELECT o FROM User o";
		TypedQuery<User> query = em.createQuery(jpql, User.class);
		return query.getResultList(); // Dùng hàm của thư viện hibernate để trả về một List
	}
}
